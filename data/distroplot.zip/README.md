**NOTE:** this plot type has been implemented in the [NVD3 library](http://nvd3.org/) as the [distroPlotChart](https://github.com/ConstantinoSchillebeeckx/nvd3/blob/master/examples/distroPlotChart.html)

---

# distroplot
D3 violin, box and swarm plots

Building on the very excellent [Violin Plot + Box Plot v3](http://bl.ocks.org/asielen/92929960988a8935d907e39e60ea8417), just putting it into a repo so that I can build off of it.

<img src='ss.png'/>
